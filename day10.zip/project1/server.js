const express = require("express");
const dotenv = require("dotenv");
const connectDB = require("./config/db");  // FIX: import correctly
const studentRoutes = require("./routes/studentRoutes");

dotenv.config();

connectDB();   // FIX: correct function name

const app = express();

app.use(express.json());
app.use("/api/students", studentRoutes);

const PORT = process.env.PORT || 5000;

// FIX: use backticks for template string
app.listen(PORT, () => console.log('server running on port ${PORT}'));