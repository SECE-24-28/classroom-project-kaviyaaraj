
import './Display5.css'

import { useEffect, useState } from "react"
 

/*const Display5=()=>{
    const[student,setStudent]=useState({
        name:"nandhini",
        gender:"female",
        mobile:12222222
    })
   
    function updateName(){
        setStudent( {name:"demo"})

           
         
    }
    return(
 <>
     
 <h1>name:{student.name}</h1>
 <h1>gender:{student.gender}</h1>
 <h1>mobile:{student.mobile}</h1>
 <button onClick={updateName}>change name</button>
 </>
    )
       
     
}
export default Display5*/

/*const Display5=()=>{
    const[student,setStudent]=useState({
        name:"nandhini",
        gender:"female",
        mobile:12222222
    })
     console.log("the current state: ",student)
    function updateName(){
        // setStudent( {name:"demo"})
      setStudent((previousData)=>{
        console.log("pre data: ..............",previousData)
return({...previousData,name:"demo",mobile:9585524527})
      })
    }
    return(
 <>
     
 <h1>name:{student.name}</h1>
 <h1>gender:{student.gender}</h1>
 <h1>mobile:{student.mobile}</h1>
 <button onClick={updateName}>change name</button>
 </>
    )
       
     
}
export default Display5*/




const Display5=()=>{

    const[data,setData]=useState(["one","two"])
      const[count,setCount]=useState(10)
 
    function addItem(){
        var item=count
        setData((pre)=>{
            return([...pre,item])
        })
setCount((t)=>{
return(t+1)
})

    }
    return(
    <>
    <h1>im from Disp5</h1>
    <button onClick={addItem}>add</button>
     <ul>
        {
            data.map((d)=>{
                    return (<li>{d}</li>)
            })
        }
     </ul>
     
    </>
)

}

export default Display5