import './Display6.css'
/*import { useState } from "react"
const Display6=()=>{
    const [name,setName] =useState("")
function info(e){
    e.preventDefault()
    console.log("my name is: ",name)
}
    return(      
        <>
        <h1>im from disp6 my name is  </h1>
      
        <form onSubmit={info}>
        <input type="text" value={name} onChange={(e)=>setName(e.target.value)}></input>
    <input type="submit" value="click here!!!!"></input>
        </form>
        </>
    )
}
export default Display6*/


/*import { useState } from "react";

const Display6=()=>{
    
     const[student,setStudent]= useState({
        username:"",
        email:""
     })
     const change=(e)=>{

setStudent((prev)=>{
return ({...prev,
    [e.target.name]:e.target.value
})
})
}
    return(
        <>
        <h1>im from disp7 {student.username} {student.email}</h1>
        <input onChange={change} name="username" value={student.username}></input>
        </>
    )
}
export default Display6;*/

import { useState } from "react";

const Display6=()=>{
    
     const[student,setStudent]= useState({
        username:"",
        email:""
     })


const formSubmit=(e)=>{
    e.preventDefault()
    console.log(student.username, student.email)
}

     const change=(e)=>{

setStudent((prev)=>{
return ({...prev,
    [e.target.name]:e.target.value
})
})
}
    return(
        <>
        <form onSubmit={formSubmit}>
        <h1>im from disp6 {student.username} {student.email}</h1>
        <input onChange={change} name="username" value={student.username}></input>
        
        <input onChange={change} name="email" value={student.email}></input> 
 
         <input type="submit"  value="click!!!!!"></input>

       </form>
        </>
    )
}
export default Display6;
//valid kudakalana andha error msg show aganu using state