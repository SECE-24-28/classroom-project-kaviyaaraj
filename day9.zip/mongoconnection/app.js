

const express=require('express')
const app=express()
const bodyParser=require('body-parser')
const exhbs=require('express-handlebars')
const dbo=require('./db')

app.engine('hbs',exhbs.engine( 
    {
        extname:"hbs",
        defaultLayout:false
        }
    )
)


app.set('view engine','hbs')
app.set('views','viewsfold')
let message ='kaviyaa'
app.use(bodyParser.urlencoded({extended:true}))
app.listen(8000,()=>{console.log('listening to port 8000')})
/*
app.get('/',(req,res)=>{
    //let message='test'
    res.render('main',{message})
})*/


app.get('/', async (req, res) => {

    let database = await dbo.getDataBase();   // FIXED
    const collection = database.collection('books')
    const cursor = collection.find({})
    let mydata = await cursor.toArray()

    switch(req.query.status ){
        case '1':
            message="inserted successfully"
            break;

        default:
            break;
    }


    res.render('main', { message: 'test', mydata })

    
})

app.get('/delete/:id' , async(req , res)=>{ 
    const database = await dbo.getDataBase();
    const  collection = database.collection('books');
    const { ObjectId } = require('mongodb');
    await collection.deleteOne( { _id : new ObjectId(req.params.id)
    });
    res.redirect('/?status=3');

})

app.get('/edit/:id',async(req , res)=>{
    const database = await dbo.getDataBase();
    const collection = database.collection('books')
    const {ObjectId} = require('mongodb')
    let b = await collection.findOne({ _id: new ObjectId(req.params.id)})

    res.render('edit' , { b })
}
)

app.post('/update/:id', async (req, res) => {
    const database = await dbo.getDataBase();
    const collection = database.collection('books');
    const { ObjectId } = require('mongodb');

    await collection.updateOne(
        { _id: new ObjectId(req.params.id) },
        { $set: { title: req.body.title1, author: req.body.author1 } }
    );

    res.redirect('/?status=2');  // Redirect back to main page with a message
});


app.post('/store_book',async(req,res)=>{
    let database = await dbo.getDataBase();   
    const collection = database.collection('books')
    let bookdata={title:req.body.title1,author:req.body.author1}
    await collection.insertOne(bookdata)
    return res.redirect('/?status=1')
})