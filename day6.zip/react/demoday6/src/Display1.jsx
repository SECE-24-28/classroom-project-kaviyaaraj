/*import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './Display1.css'


function Display1()
{
    function changeName(d) {
      var name=d
       console.log("im inside the display1",{name})
    }
    var name="demo"
    console.log("im inside the display1",{name})
    return(
        <>
        <h1>im from display1{name} </h1>
        <button onClick={()=>{changeName('not demo')}}>click here!!

        </button>
        </>
    )
}
export default Display1*/

import { useContext, useState } from "react"
import { allDatas } from "./App"

function Display1(){
    const {name}=useContext(allDatas)
    // const {val}=datas;
    console.log("the data from display: ",{name})
    const [myName,setMyName]= useState("hello")
 
    console.log("im inside the disp1",{myName})
   
    return(
        <>
        <h1>im from dis1{myName}</h1>
        <h1>i've recevied from myGP thru my Parent {name}
             
        </h1>
<button onClick={()=>{setMyName('not demo')}}>click here!!!!</button>
</>
    )
}

export default Display1