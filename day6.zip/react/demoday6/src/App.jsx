/*import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Display from './Display'
import Display1 from './Display1'


  function App() {
    var name = "kaviyaa"
    var val1=23;
    const arr=[12,23,34]
    const person ={name:"sai",gender:"male"}
  return (
    <>
   <h1>Hello !!!</h1>
   <Display name={name} a={val1} arr={arr} obj={person} />
   <Display1/>
   </>
  )
}
export default App*/



import { createContext, useState } from "react";
import Display from "./Display"
import Display1 from "./Display1";
export const allDatas=createContext()
function App() 
{
   const [data,setData]=useState();
  var name="hello im the parent"
  var val1=23
  var arr=[12,34,5]
  const person={name:"sai",gender:"male"}
 const receive=(d)=>{
  console.log("got it",d)
  setData(d)
 }
  return (
    <allDatas.Provider value={{name,val1,person,receive,arr}}>
     <h1> welcome  </h1>
     <h1> i've recevied from parent. {data}</h1>
     <h1>--------------------------</h1>
      {/* <Display name={name} a={val1} arr={arr} obj={person}  receive={receive}/> */}
      <Display/>
</allDatas.Provider> 
      
  )
}

export default App

 
